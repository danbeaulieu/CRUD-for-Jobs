package play.modules.crudjobs;

public abstract class ProgressHandler {

	public abstract void handle(Integer value);
}
